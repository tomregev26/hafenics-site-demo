-- new and imporved data charts
-- payments id
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000000', 'Yaara', 'Sadeh');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000001', 'David', 'Goldstein');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000002', 'Shani', 'Avraham');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000003', 'Yaron', 'Perez');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000004', 'Yaara', 'Cohen');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000005', 'Nir', 'Goldstein');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000006', 'Omer', 'Ben-David');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000007', 'Shani', 'Levy');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000008', 'Yaron', 'Sadeh');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000009', 'Micha', 'Avraham');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000010', 'Micha', 'Goldstein');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000011', 'Yaara', 'Cohen');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000012', 'Omer', 'Levy');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000013', 'Tomer', 'Zohar');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000014', 'Ronen', 'Levy');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000015', 'Shani', 'Cohen');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000016', 'Omer', 'Levy');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000017', 'Yaara', 'Avraham');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000018', 'Shani', 'Zohar');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000019', 'Tomer', 'Avraham');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000020', 'Tomer', 'Goldstein');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000021', 'Omer', 'Avraham');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000022', 'Lior', 'Zohar');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000023', 'Yaara', 'Levy');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000024', 'Omer', 'Mizrahi');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000025', 'Lior', 'Avraham');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000026', 'Yaara', 'Shapiro');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000027', 'Nir', 'Mizrahi');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000028', 'Micha', 'Avraham');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000029', 'Micha', 'Goldstein');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000030', 'Ronen', 'Levy');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000031', 'Shani', 'Goldstein');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000032', 'Yaara', 'Ben-David');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000033', 'Micha', 'Goldstein');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000034', 'Omer', 'Shapiro');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000035', 'Nir', 'Avraham');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000036', 'Yaron', 'Shapiro');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000037', 'Shani', 'Goldstein');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000038', 'Micha', 'Cohen');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000039', 'David', 'Mizrahi');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000040', 'Yaron', 'Shapiro');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000041', 'Yaara', 'Mizrahi');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000042', 'Tomer', 'Avraham');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000043', 'Omer', 'Ben-David');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000044', 'Shani', 'Perez');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000045', 'Omer', 'Perez');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000046', 'Nir', 'Levy');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000047', 'Yaara', 'Shapiro');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000048', 'Lior', 'Ben-David');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000049', 'Ronen', 'Shapiro');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000050', 'Tomer', 'Sadeh');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000051', 'Tomer', 'Avraham');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000052', 'Tomer', 'Levy');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000053', 'Micha', 'Ben-David');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000054', 'Tomer', 'Ben-David');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000055', 'Tomer', 'Cohen');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000056', 'Nir', 'Ben-David');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000057', 'Ronen', 'Zohar');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000058', 'Shani', 'Cohen');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000059', 'Lior', 'Shapiro');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000060', 'Omer', 'Cohen');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000061', 'Lior', 'Levy');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000062', 'Tomer', 'Zohar');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000063', 'Yaron', 'Levy');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000064', 'Yaara', 'Zohar');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000065', 'Shani', 'Cohen');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000066', 'Ronen', 'Zohar');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000067', 'David', 'Zohar');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000068', 'Nir', 'Goldstein');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000069', 'Micha', 'Ben-David');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000070', 'Yaara', 'Levy');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000071', 'David', 'Perez');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000072', 'Yaara', 'Zohar');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000073', 'Tomer', 'Sadeh');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000074', 'Yaron', 'Shapiro');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000075', 'Yaara', 'Sadeh');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000076', 'Tomer', 'Zohar');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000077', 'Tomer', 'Cohen');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000078', 'Yaron', 'Mizrahi');
INSERT INTO Payments_ID (ID, First_Name, Last_Name) VALUES ('1000000079', 'Shani', 'Cohen');


--payments
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('7460000000000000',  '01/09/2025', '321', '1000000000');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('6180000000000000',  '01/10/2025', '321', '1000000001');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('5200000000000000',  '01/08/2025', '654', '1000000002');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('6290000000000000',  '01/11/2025', '654', '1000000003');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('2120000000000000',  '01/09/2025', '456', '1000000004');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('9420000000000000',  '01/08/2025', '456', '1000000005');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('1710000000000000',  '01/12/2025', '456', '1000000006');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('6630000000000000',  '01/11/2025', '789', '1000000007');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('2520000000000000',  '01/11/2025', '123', '1000000008');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('9120000000000000',  '01/09/2025', '321', '1000000009');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('8780000000000000',  '01/10/2025', '321', '1000000010');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('6860000000000000',  '01/08/2025', '456', '1000000011');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('9010000000000000',  '01/10/2025', '123', '1000000012');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('3210000000000000',  '01/11/2025', '123', '1000000013');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('1540000000000000',  '01/12/2025', '789', '1000000014');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('4060000000000000',  '01/12/2025', '123', '1000000015');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('9900000000000000',  '01/10/2025', '789', '1000000016');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('6060000000000000',  '01/12/2025', '789', '1000000017');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('5050000000000000',  '01/09/2025', '789', '1000000018');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('4460000000000000',  '01/09/2025', '123', '1000000019');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('3960000000000000',  '01/10/2025', '789', '1000000020');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('9970000000000000',  '01/08/2025', '789', '1000000021');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('1810000000000000',  '01/09/2025', '654', '1000000022');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('4180000000000000',  '01/12/2025', '789', '1000000023');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('8581000000000000',  '01/11/2025', '654', '1000000024');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('8630000000000000',  '01/09/2025', '789', '1000000025');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('4630000000000000',  '01/09/2025', '654', '1000000026');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('2750000000000000',  '01/08/2025', '456', '1000000027');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('5060000000000000',  '01/11/2025', '654', '1000000028');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('2160000000000000',  '01/12/2025', '321', '1000000029');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('9460000000000000',  '01/10/2025', '321', '1000000030');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('5500000000000000',  '01/12/2025', '123', '1000000031');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('5270000000000000',  '01/10/2025', '321', '1000000032');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('3950000000000000',  '01/08/2025', '321', '1000000033');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('8590000000000000',  '01/11/2025', '456', '1000000034');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('5410000000000000',  '01/09/2025', '789', '1000000035');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('3980000000000000',  '01/09/2025', '123', '1000000036');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('9100000000000000',  '01/11/2025', '789', '1000000037');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('3390000000000000',  '01/09/2025', '789', '1000000038');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('5330000000000000',  '01/11/2025', '789', '1000000039');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('8580000000000000',  '01/11/2025', '654', '1000000040');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('6160000000000000',  '01/11/2025', '654', '1000000041');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('4770000000000000',  '01/08/2025', '321', '1000000042');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('7980000000000000',  '01/10/2025', '123', '1000000043');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('2240000000000000',  '01/11/2025', '321', '1000000044');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('4390000000000000',  '01/09/2025', '321', '1000000045');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('4190000000000000',  '01/12/2025', '456', '1000000046');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('5360000000000000',  '01/12/2025', '123', '1000000047');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('9480000000000000',  '01/11/2025', '321', '1000000048');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('5320000000000000',  '01/08/2025', '789', '1000000049');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('2100000000000000',  '01/10/2025', '789', '1000000050');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('4110000000000000',  '01/09/2025', '789', '1000000051');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('9320000000000000',  '01/12/2025', '123', '1000000052');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('2820000000000000',  '01/10/2025', '456', '1000000053');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('1980000000000000',  '01/10/2025', '654', '1000000054');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('7030000000000000',  '01/10/2025', '654', '1000000055');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('4720000000000000',  '01/12/2025', '789', '1000000056');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('9690000000000000',  '01/11/2025', '789', '1000000057');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('6760000000000000',  '01/10/2025', '321', '1000000058');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('7920000000000000',  '01/08/2025', '654', '1000000059');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('7510000000000000',  '01/10/2025', '654', '1000000060');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('9280000000000000',  '01/12/2025', '789', '1000000061');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('7750000000000000',  '01/12/2025', '654', '1000000062');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('1970000000000000',  '01/12/2025', '321', '1000000063');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('5450000000000000',  '01/12/2025', '654', '1000000064');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('2010000000000000',  '01/12/2025', '123', '1000000065');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('2680000000000000',  '01/09/2025', '654', '1000000066');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('7070000000000000',  '01/12/2025', '654', '1000000067');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('4850000000000000',  '01/09/2025', '321', '1000000068');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('9840000000000000',  '01/08/2025', '654', '1000000069');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('4450000000000000',  '01/09/2025', '654', '1000000070');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('6250000000000000',  '01/09/2025', '654', '1000000071');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('3130000000000000',  '01/12/2025', '789', '1000000072');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('4650000000000000',  '01/11/2025', '789', '1000000073');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('2060000000000000',  '01/08/2025', '789', '1000000074');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('9620000000000000',  '01/09/2025', '654', '1000000075');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('4750000000000000',  '01/11/2025', '123', '1000000076');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('6980000000000000',  '01/12/2025', '456', '1000000077');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('8090000000000000',  '01/09/2025', '321', '1000000078');
INSERT INTO Payments (Credit_Card_Number, Exp_Date, CVV, ID) VALUES ('9260000000000000',  '01/09/2025', '321', '1000000079');


--passengers
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000000', 'Yaara', 'Sadeh', '1950-03-15', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000001', 'Adir', 'Even', '1955-01-01', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000002', 'Shani', 'Avraham', '1950-05-10', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000003', 'Yaron', 'Perez', '1995-08-16', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000004', 'Yaara', 'Cohen', '1990-07-14', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000005', 'Nir', 'Goldstein', '1990-02-10', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000006', 'Omer', 'Ben-David', '1993-03-10', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000007', 'Shani', 'Levy', '1988-02-22', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000008', 'Yaron', 'Sadeh', '1999-04-08', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000009', 'Micha', 'Avraham', '1980-09-21', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000010', 'Micha', 'Goldstein', '1995-03-21', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000011', 'Yaara', 'Cohen', '1995-11-28', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000012', 'Omer', 'Levy', '1991-04-02', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000013', 'Tomer', 'Zohar', '1996-07-08', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000014', 'Ronen', 'Levy', '1994-01-24', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000015', 'Shani', 'Cohen', '1993-05-11', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000016', 'Omer', 'Levy', '1987-07-25', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000017', 'Yaara', 'Avraham', '1988-06-08', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000018', 'Shani', 'Zohar', '1996-09-18', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000019', 'Tomer', 'Avraham', '1999-12-04', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000020', 'Tomer', 'Goldstein', '1988-12-24', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000021', 'Omer', 'Avraham', '1982-11-24', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000022', 'Lior', 'Zohar', '1982-07-06', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000023', 'Yaara', 'Levy', '1984-01-05', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000024', 'Omer', 'Mizrahi', '1988-05-09', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000025', 'Lior', 'Avraham', '1985-05-16', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000026', 'Yaara', 'Shapiro', '1981-09-30', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000027', 'Nir', 'Mizrahi', '1994-02-25', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000028', 'Micha', 'Avraham', '1986-12-22', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000029', 'Micha', 'Goldstein', '1996-03-14', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000030', 'Ronen', 'Levy', '1985-09-18', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000031', 'Shani', 'Goldstein', '2000-02-05', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000032', 'Yaara', 'Ben-David', '1993-03-21', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000033', 'Micha', 'Goldstein', '1984-08-31', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000034', 'Omer', 'Shapiro', '1990-09-22', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000035', 'Nir', 'Avraham', '1995-11-29', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000036', 'Yaron', 'Shapiro', '1983-08-14', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000037', 'Shani', 'Goldstein', '1999-03-19', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000038', 'Micha', 'Cohen', '1996-10-12', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000039', 'David', 'Mizrahi', '1986-08-05', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000040', 'Yaron', 'Shapiro', '1992-12-11', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000041', 'Yaara', 'Mizrahi', '1982-10-31', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000042', 'Tomer', 'Avraham', '1999-08-30', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000043', 'Omer', 'Ben-David', '1998-05-31', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000044', 'Shani', 'Perez', '1981-12-10', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000045', 'Omer', 'Perez', '1994-10-04', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000046', 'Nir', 'Levy', '1981-02-26', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000047', 'Yaara', 'Shapiro', '1980-02-24', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000048', 'Lior', 'Ben-David', '1993-09-17', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000049', 'Ronen', 'Shapiro', '1989-12-23', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000050', 'Tomer', 'Sadeh', '1983-07-22', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000051', 'Tomer', 'Avraham', '1994-10-19', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000052', 'Tomer', 'Levy', '1997-04-04', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000053', 'Micha', 'Ben-David', '1998-09-13', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000054', 'Tomer', 'Ben-David', '1985-10-04', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000055', 'Tomer', 'Cohen', '1985-11-27', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000056', 'Nir', 'Ben-David', '1990-08-01', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000057', 'Ronen', 'Zohar', '1984-09-16', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000058', 'Shani', 'Cohen', '1981-08-01', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000059', 'Lior', 'Shapiro', '1997-02-22', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000060', 'Omer', 'Cohen', '1997-05-19', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000061', 'Lior', 'Levy', '1983-03-28', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000062', 'Tomer', 'Zohar', '1995-08-28', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000063', 'Yaron', 'Levy', '1988-03-14', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000064', 'Yaara', 'Zohar', '1988-05-10', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000065', 'Shani', 'Cohen', '1982-06-08', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000066', 'Ronen', 'Zohar', '1987-12-13', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000067', 'David', 'Zohar', '1983-04-18', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000068', 'Nir', 'Goldstein', '1990-10-25', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000069', 'Micha', 'Ben-David', '2000-07-22', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000070', 'Yaara', 'Levy', '1988-08-06', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000071', 'David', 'Perez', '1980-09-14', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000072', 'Yaara', 'Zohar', '1987-01-19', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000073', 'Tomer', 'Sadeh', '1984-05-17', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000074', 'Yaron', 'Shapiro', '1992-09-02', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000075', 'Yaara', 'Sadeh', '1982-11-19', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000076', 'Tomer', 'Zohar', '1994-04-16', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000077', 'Tomer', 'Cohen', '1986-03-04', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000078', 'Yaron', 'Mizrahi', '1987-09-08', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000079', 'Shani', 'Cohen', '1994-02-26', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000080', 'Liam', 'Adler', '1997-12-25', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000081', 'Shiri - Katlina', 'Nitzan', '1980-10-14', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000082', 'Noah', 'Stein', '1986-02-28', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000083', 'Olivia', 'Weiss', '1990-12-24', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000084', 'Ethan', 'Kaplan', '1980-09-13', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000085', 'Sophia', 'Rosen', '1980-09-14', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000086', 'James', 'Levine', '1992-04-24', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000087', 'Isabella', 'Levy', '1986-02-04', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000088', 'Benjamin', 'Gold', '1990-11-19', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000089', 'Mason', 'Greenberg', '1991-06-21', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000090', 'Mia', 'Katz', '1989-02-01', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000091', 'Logan', 'Horowitz', '1998-11-21', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000092', 'Charlotte', 'Silver', '1963-08-22', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000093', 'Alexander', 'Blum', '1984-08-13', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000094', 'Amelia', 'Gross', '1955-01-27', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000095', 'Harper', 'Schwartz', '1993-12-18', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000096', 'Aiden', 'Cohen', '1988-02-17', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000097', 'Abigail', 'Fischer', '1980-06-03', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000098', 'Ella', 'Shulman', '1982-12-25', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000099', 'Henry', 'Baron', '1999-03-22', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000100', 'Emily', 'Rubin', '1984-12-12', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000101', 'Elijah', 'Abramson', '1983-12-30', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000102', 'Scarlett', 'Lerner', '1992-01-12', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000103', 'Levi', 'Peretz', '1982-07-27', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000104', 'Sofia', 'Goldberg', '1992-11-02', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000105', 'William', 'Rosenthal', '1998-10-11', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000106', 'Grace', 'Edelman', '1992-05-16', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000107', 'Daniel', 'Tenenbaum', '1994-05-15', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000108', 'Aria', 'Lazar', '1987-01-10', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000109', 'Sebastian', 'Feldman', '1999-06-20', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000110', 'Zoey', 'Isaacson', '1982-07-21', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000111', 'Eli', 'Geller', '2000-01-30', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000112', 'Natalie', 'Shapiro', '1982-07-31', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000113', 'Henry', 'Baum', '2000-09-13', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000114', 'Victoria', 'Kagan', '1959-01-04', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000115', 'Ella', 'Gordon', '1989-06-07', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000116', 'Hazel', 'Fox', '1983-03-26', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000117', 'Oliver', 'Wexler', '1980-07-18', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000118', 'Grace', 'Lang', '1995-08-06', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000119', 'Max', 'Litman', '1996-12-18', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000120', 'Hannah', 'Weinberg', '1983-11-27', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000121', 'Chloe', 'Freedman', '1997-12-22', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000122', 'Jack', 'Brandt', '1997-08-05', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000123', 'Lily', 'Weiner', '1990-07-16', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000124', 'Jacob', 'Feinberg', '1995-11-03', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000125', 'Zoe', 'Bernstein', '1982-05-28', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000126', 'Lucas', 'Halpern', '1992-03-20', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000127', 'Ava', 'Pomerantz', '1985-10-25', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000128', 'Nathan', 'Friedman', '1983-02-02', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000129', 'Mila', 'Roth', '1991-05-24', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000130', 'Samuel', 'Hoffman', '1989-01-23', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000131', 'Aiden', 'Goldman', '1992-01-17', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000132', 'Emily', 'Rabinowitz', '1984-11-18', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000133', 'Hannah', 'Silverman', '1999-09-25', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000134', 'Julian', 'Eisen', '1997-01-08', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000135', 'Ella', 'Fisher', '1981-02-18', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000136', 'Adam', 'Leventhal', '1986-10-08', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000137', 'Nora', 'Weissman', '1982-12-22', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000138', 'Ryan', 'Glazer', '1988-09-13', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000139', 'Maya', 'Brenner', '1986-09-14', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000140', 'Eliana', 'Siegel', '1997-09-21', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000141', 'Oliver', 'Waldman', '1996-01-23', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000142', 'Madeline', 'Schneider', '1983-10-22', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000143', 'Noah', 'Rosenbaum', '1997-11-06', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000144', 'Leah', 'Abrams', '1995-06-28', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000145', 'Jayden', 'Altman', '1994-05-14', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000146', 'Harper', 'Goldfarb', '1989-12-08', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000147', 'Zachary', 'Spiegel', '2000-02-29', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000148', 'Evelyn', 'Isaacs', '1990-12-02', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000149', 'Caleb', 'Jacobs', '1992-04-12', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000150', 'Audrey', 'Levinsky', '2000-04-01', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000151', 'James', 'Hersh', '1994-03-19', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000152', 'Sophie', 'Tobias', '2000-11-13', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000153', 'Dylan', 'Shore', '1991-08-11', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000154', 'Isaac', 'Berger', '1986-02-07', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000155', 'Victoria', 'Goldstein', '1996-12-11', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000156', 'Luke', 'Shain', '1996-07-12', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000157', 'Hailey', 'Langman', '1981-03-30', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000158', 'Gabriel', 'Silverstein', '1982-12-29', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000159', 'Ellie', 'Brand', '1993-03-17', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000160', 'Hannah', 'Klein', '1996-07-06', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000161', 'Emily', 'Oren', '1983-02-26', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000162', 'Ethan', 'Ginzburg', '1985-11-24', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000163', 'Liam', 'Rothberg', '1989-11-02', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000164', 'Aria', 'Shamir', '2000-02-17', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000165', 'Andrew', 'Zisman', '1983-12-07', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000166', 'Avery', 'Sandler', '1995-06-05', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000167', 'Nathan', 'Shaffer', '1986-04-07', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000168', 'Logan', 'Ziv', '1982-01-03', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000169', 'Layla', 'Goldfarb', '1960-04-24', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000170', 'Isaiah', 'Hirsch', '1991-04-16', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000171', 'Leah', 'Rabin', '1994-04-06', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000172', 'Daniel', 'Schwartzman', '1992-07-03', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000173', 'Caroline', 'Oppenheimer', '1996-09-13', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000174', 'Benjamin', 'Weisman', '1997-04-17', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000175', 'Scarlett', 'Rabinovitz', '1992-01-07', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000176', 'Emma', 'Levitt', '1989-08-17', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000177', 'Harper', 'Feldstein', '1994-03-20', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000178', 'Eleanor', 'Goldwasser', '2000-01-16', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000179', 'Asher', 'Korn', '1981-10-19', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000180', 'Anna', 'Goldbaum', '2000-09-10', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000181', 'Leo', 'Lerner', '1997-05-11', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000182', 'Eli', 'Weinstock', '1983-01-05', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000183', 'Sophia', 'Goldberg', '2000-09-10', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000184', 'Julian', 'Hershkowitz', '1982-12-03', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000185', 'Charlotte', 'Blumenthal', '2000-06-10', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000186', 'Mila', 'Schreiber', '1993-09-24', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000187', 'Ava', 'Bregman', '2000-03-29', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000188', 'Jacob', 'Solomon', '1989-06-20', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000189', 'Madeline', 'Kaufman', '1983-03-24', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000190', 'Liam', 'Lieberman', '1999-09-29', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000191', 'Olivia', 'Edelstein', '1996-08-11', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000192', 'William', 'Rosenfeld', '1990-07-28', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000193', 'Grace', 'Wolowitz', '1995-11-14', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000194', 'Lucas', 'Teitelbaum', '1982-08-24', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000195', 'Emily', 'Katzman', '1988-10-28', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000196', 'Zachary', 'Tishman', '1988-02-06', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000197', 'Mila', 'Braun', '1998-06-01', 'Female');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000198', 'Alexander', 'Kesselman', '1985-04-03', 'Male');
INSERT INTO Passengers (ID, First_Name, Last_Name, Birthdate, Gender) VALUES ('1000000199', 'Aria', 'Rabinowitz', '1994-03-03', 'Male');


--main customer
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000000', '504399959', 'yaara.sadeh@gmail.com', 'Tel Aviv', 'Dizengoff', '43');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000001', '509146024', 'adir.even@gmail.com', 'Tel Aviv', 'Herzl', '967');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000002', '524835245', 'shani.avraham@gmail.com', 'Haifa', 'Herzl', '63');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000003', '509901607', 'yaron.perez@gmail.com', 'Eilat', 'Rothschild', '577');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000004', '528083940', 'yaara.cohen@gmail.com', 'Beersheba', 'King George', '149');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000005', '525810284', 'nir.goldstein@gmail.com', 'Jerusalem', 'Herzl', '543');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000006', '501347810', 'omer.ben-david@gmail.com', 'Beersheba', 'Rothschild', '26');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000007', '528351980', 'shani.levy@gmail.com', 'Eilat', 'Ben Yehuda', '514');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000008', '505781672', 'yaron.sadeh@gmail.com', 'Eilat', 'Rothschild', '517');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000009', '526401823', 'micha.avraham@gmail.com', 'Jerusalem', 'Dizengoff', '77');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000010', '525572182', 'micha.goldstein@gmail.com', 'Tel Aviv', 'Herzl', '43');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000011', '528722377', 'yaara.cohen@gmail.com', 'Tel Aviv', 'Rothschild', '872');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000012', '504318488', 'omer.levy@gmail.com', 'Tel Aviv', 'Herzl', '822');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000013', '509593230', 'tomer.zohar@gmail.com', 'Tel Aviv', 'King George', '222');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000014', '501482157', 'ronen.levy@gmail.com', 'Haifa', 'Rothschild', '239');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000015', '527063925', 'shani.cohen@gmail.com', 'Beersheba', 'Dizengoff', '799');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000016', '524582533', 'omer.levy@gmail.com', 'Beersheba', 'King George', '317');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000017', '522674936', 'yaara.avraham@gmail.com', 'Tel Aviv', 'Herzl', '56');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000018', '526327565', 'shani.zohar@gmail.com', 'Jerusalem', 'Herzl', '709');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000019', '522648247', 'tomer.avraham@gmail.com', 'Tel Aviv', 'Herzl', '63');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000020', '526468211', 'tomer.goldstein@gmail.com', 'Haifa', 'Herzl', '2');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000021', '523807244', 'omer.avraham@gmail.com', 'Jerusalem', 'Dizengoff', '72');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000022', '527533907', 'lior.zohar@gmail.com', 'Jerusalem', 'Herzl', '930');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000023', '525574843', 'yaara.levy@gmail.com', 'Jerusalem', 'Ben Yehuda', '554');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000024', '528923025', 'omer.mizrahi@gmail.com', 'Beersheba', 'King George', '92');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000025', '525458228', 'lior.avraham@gmail.com', 'Eilat', 'Ben Yehuda', '163');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000026', '509115481', 'yaara.shapiro@gmail.com', 'Tel Aviv', 'Ben Yehuda', '229');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000027', '527123697', 'nir.mizrahi@gmail.com', 'Beersheba', 'Dizengoff', '564');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000028', '501436834', 'micha.avraham@gmail.com', 'Eilat', 'King George', '243');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000029', '505656766', 'micha.goldstein@gmail.com', 'Eilat', 'Herzl', '443');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000030', '508592916', 'ronen.levy@gmail.com', 'Tel Aviv', 'Dizengoff', '134');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000031', '505526345', 'shani.goldstein@gmail.com', 'Eilat', 'Rothschild', '419');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000032', '526502233', 'yaara.ben-david@gmail.com', 'Beersheba', 'Rothschild', '972');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000033', '524492270', 'micha.goldstein@gmail.com', 'Tel Aviv', 'Dizengoff', '510');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000034', '501382137', 'omer.shapiro@gmail.com', 'Tel Aviv', 'Herzl', '78');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000035', '503274590', 'nir.avraham@gmail.com', 'Tel Aviv', 'Rothschild', '48');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000036', '528473867', 'yaron.shapiro@gmail.com', 'Eilat', 'Herzl', '418');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000037', '526499807', 'shani.goldstein@gmail.com', 'Jerusalem', 'Ben Yehuda', '589');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000038', '507653782', 'micha.cohen@gmail.com', 'Haifa', 'Herzl', '7');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000039', '506176149', 'david.mizrahi@gmail.com', 'Jerusalem', 'Dizengoff', '4');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000040', '529164577', 'yaron.shapiro@gmail.com', 'Beersheba', 'Dizengoff', '657');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000041', '504563653', 'yaara.mizrahi@gmail.com', 'Eilat', 'Herzl', '9');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000042', '506354484', 'tomer.avraham@gmail.com', 'Beersheba', 'Dizengoff', '305');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000043', '501951700', 'omer.ben-david@gmail.com', 'Eilat', 'Ben Yehuda', '154');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000044', '503920111', 'shani.perez@gmail.com', 'Tel Aviv', 'Herzl', '98');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000045', '507768122', 'omer.perez@gmail.com', 'Eilat', 'Herzl', '142');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000046', '505174928', 'nir.levy@gmail.com', 'Jerusalem', 'Rothschild', '11');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000047', '527096670', 'yaara.shapiro@gmail.com', 'Jerusalem', 'Rothschild', '975');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000048', '507706248', 'lior.ben-david@gmail.com', 'Haifa', 'Ben Yehuda', '92');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000049', '504302598', 'ronen.shapiro@gmail.com', 'Beersheba', 'Ben Yehuda', '539');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000050', '505638709', 'tomer.sadeh@gmail.com', 'Beersheba', 'Dizengoff', '76');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000051', '527312445', 'tomer.avraham@gmail.com', 'Haifa', 'Rothschild', '575');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000052', '508843370', 'tomer.levy@gmail.com', 'Jerusalem', 'Dizengoff', '862');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000053', '522162533', 'micha.ben-david@gmail.com', 'Eilat', 'Dizengoff', '432');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000054', '501913273', 'tomer.ben-david@gmail.com', 'Tel Aviv', 'Ben Yehuda', '290');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000055', '525423480', 'tomer.cohen@gmail.com', 'Haifa', 'King George', '34');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000056', '525457117', 'nir.ben-david@gmail.com', 'Haifa', 'Ben Yehuda', '822');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000057', '527079115', 'ronen.zohar@gmail.com', 'Haifa', 'Dizengoff', '731');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000058', '502693580', 'shani.cohen@gmail.com', 'Eilat', 'Dizengoff', '671');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000059', '528368904', 'lior.shapiro@gmail.com', 'Jerusalem', 'Dizengoff', '719');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000060', '526449354', 'omer.cohen@gmail.com', 'Haifa', 'Ben Yehuda', '637');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000061', '521579907', 'lior.levy@gmail.com', 'Tel Aviv', 'King George', '6');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000062', '508982555', 'tomer.zohar@gmail.com', 'Beersheba', 'King George', '155');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000063', '506646210', 'yaron.levy@gmail.com', 'Beersheba', 'Ben Yehuda', '28');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000064', '527087896', 'yaara.zohar@gmail.com', 'Jerusalem', 'Rothschild', '965');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000065', '528214108', 'shani.cohen@gmail.com', 'Jerusalem', 'Rothschild', '808');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000066', '508773121', 'ronen.zohar@gmail.com', 'Tel Aviv', 'Rothschild', '428');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000067', '505270780', 'david.zohar@gmail.com', 'Eilat', 'Herzl', '74');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000068', '527712161', 'nir.goldstein@gmail.com', 'Tel Aviv', 'King George', '111');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000069', '528566327', 'micha.ben-david@gmail.com', 'Jerusalem', 'King George', '321');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000070', '509897935', 'yaara.levy@gmail.com', 'Beersheba', 'Dizengoff', '168');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000071', '525979914', 'david.perez@gmail.com', 'Haifa', 'Dizengoff', '968');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000072', '502838192', 'yaara.zohar@gmail.com', 'Jerusalem', 'Ben Yehuda', '140');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000073', '505286217', 'tomer.sadeh@gmail.com', 'Eilat', 'Herzl', '37');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000074', '523111002', 'yaron.shapiro@gmail.com', 'Tel Aviv', 'Ben Yehuda', '123');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000075', '526805844', 'yaara.sadeh@gmail.com', 'Haifa', 'King George', '21');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000076', '522863053', 'tomer.zohar@gmail.com', 'Jerusalem', 'King George', '95');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000077', '525894365', 'tomer.cohen@gmail.com', 'Beersheba', 'King George', '682');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000078', '504059126', 'yaron.mizrahi@gmail.com', 'Eilat', 'Dizengoff', '471');
INSERT INTO Main_Customer (ID, Phone, Email, Adress_City, Adress_Street, Adress_Number) VALUES ('1000000079', '525822843', 'shani.cohen@gmail.com', 'Tel Aviv', 'Dizengoff', '745');

--orders
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('1', '2024-01-30', '2024-02-09', '2024-04-08', '7460000000000000', 7);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('2', '2024-05-30', '2024-06-02', '2024-07-05', '6180000000000000', 10);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('3', '2024-02-27', '2024-03-02', '2024-03-15', '5200000000000000', 3);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('4', '2024-06-29', '2025-07-02', '2025-08-08', '6290000000000000', 2);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('5', '2024-06-29', '2025-07-11', '2025-08-15', '2120000000000000', 6);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('6', '2024-05-29', '2024-05-31', '2024-06-10', '9420000000000000', 1);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('7', '2024-05-30', '2025-01-21', '2025-02-02', '1710000000000000', 2);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('8', '2024-02-27', '2025-01-17', '2025-02-07', '6630000000000000', 10);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('9', '2024-12-30', '2024-01-25', '2024-03-21', '2520000000000000', 1);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('10', '2024-02-27', '2025-01-06', '2025-02-09', '9120000000000000', 10);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('11', '2024-02-27', '2024-01-18', '2024-02-16', '8780000000000000', 10);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('12', '2024-02-27', '2024-01-13', '2024-02-21', '6860000000000000', 2);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('13', '2025-01-19', '2025-01-15', '2025-02-28', '9010000000000000', 6);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('14', '2024-06-29', '2025-07-06', '2025-07-20', '3210000000000000', 5);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('15', '2025-01-19', '2025-01-10', '2025-02-28', '1540000000000000', 8);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('16', '2025-02-27', '2025-03-23', '2025-04-30', '4060000000000000', 10);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('17', '2025-06-29', '2025-07-07', '2025-08-08', '9900000000000000', 6);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('18', '2025-01-30', '2025-02-05', '2025-02-11', '6060000000000000', 1);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('19', '2025-12-30', '2026-01-12', '2026-03-11', '5050000000000000', 3);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('20', '2025-01-29', '2025-01-31', '2025-03-05', '4460000000000000', 6);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('21', '2025-02-27', '2025-03-04', '2025-04-02', '3950000000000000', 8);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('22', '2025-04-29', '2025-05-18', '2025-07-09', '9970000000000000', 3);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('23', '2025-01-30', '2025-02-07', '2025-02-11', '1810000000000000', 4);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('24', '2025-05-30', '2025-06-13', '2025-07-13', '4180000000000000', 10);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('25', '2025-05-30', '2025-06-04', '2025-06-13', '8590000000000000', 1);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('26', '2025-01-29', '2025-01-30', '2025-03-04', '8630000000000000', 6);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('27', '2025-03-30', '2025-04-27', '2025-05-24', '4630000000000000', 9);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('28', '2025-05-30', '2025-06-20', '2025-07-20', '2750000000000000', 7);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('29', '2025-05-30', '2025-06-02', '2025-07-09', '5060000000000000', 4);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('30', '2025-05-30', '2025-06-29', '2025-07-03', '2160000000000000', 1);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('31', '2025-03-30', '2025-04-05', '2025-05-11', '9460000000000000', 10);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('32', '2025-04-29', '2025-05-01', '2025-05-31', '5500000000000000', 6);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('33', '2025-05-30', '2025-06-06', '2025-07-20', '5270000000000000', 3);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('34', '2025-02-27', '2025-03-03', '2025-04-24', '3950000000000000', 8);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('35', '2024-12-30', '2025-01-21', '2025-02-10', '8590000000000000', 1);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('36', '2025-02-27', '2025-03-23', '2025-05-09', '5410000000000000', 3);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('37', '2025-01-30', '2025-02-19', '2025-02-21', '3980000000000000', 6);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('38', '2025-02-27', '2025-03-10', '2025-04-05', '9100000000000000', 8);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('39', '2025-05-30', '2025-06-25', '2025-07-12', '3390000000000000', 10);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('40', '2025-02-27', '2025-03-14', '2025-05-06', '5330000000000000', 9);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('41', '2025-06-29', '2025-07-09', '2025-07-10', '8580000000000000', 10);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('42', '2025-05-30', '2025-06-07', '2025-07-25', '6160000000000000', 2);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('43', '2025-04-29', '2025-05-23', '2025-06-06', '4770000000000000', 6);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('44', '2025-05-30', '2025-06-28', '2025-08-05', '7980000000000000', 2);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('45', '2025-04-29', '2025-05-18', '2025-05-23', '2240000000000000', 4);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('46', '2025-04-29', '2025-05-23', '2025-05-26', '4390000000000000', 9);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('47', '2025-05-30', '2025-06-15', '2025-07-13', '4190000000000000', 2);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('48', '2025-03-30', '2025-04-26', '2025-05-19', '5360000000000000', 10);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('49', '2025-04-29', '2025-04-30', '2025-06-14', '9480000000000000', 7);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('50', '2025-03-29', '2025-03-30', '2025-04-04', '5320000000000000', 6);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('51', '2025-05-30', '2025-06-02', '2025-07-07', '2100000000000000', 8);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('52', '2025-01-30', '2025-02-11', '2025-02-15', '4110000000000000', 8);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('53', '2025-02-27', '2025-03-20', '2025-05-19', '9320000000000000', 5);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('54', '2025-06-29', '2025-06-30', '2025-08-27', '2820000000000000', 10);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('55', '2025-02-27', '2025-03-27', '2025-04-01', '1980000000000000', 7);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('56', '2025-03-30', '2025-04-28', '2025-06-27', '7030000000000000', 8);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('57', '2025-12-30', '2026-01-16', '2026-02-16', '4720000000000000', 8);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('58', '2025-12-30', '2026-01-16', '2026-01-19', '9690000000000000', 7);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('59', '2025-01-30', '2025-02-12', '2025-03-03', '6860000000000000', 2);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('60', '2025-01-30', '2025-02-25', '2025-03-24', '7920000000000000', 4);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('61', '2025-03-30', '2025-04-20', '2025-05-02', '7510000000000000', 7);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('62', '2025-02-27', '2025-03-01', '2025-04-20', '9280000000000000', 3);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('63', '2025-01-30', '2025-02-05', '2025-02-14', '7750000000000000', 7);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('64', '2025-04-29', '2025-05-01', '2025-06-20', '1970000000000000', 9);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('65', '2025-05-30', '2025-06-20', '2025-08-01', '5450000000000000', 5);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('66', '2025-02-27', '2025-03-09', '2025-04-25', '2010000000000000', 9);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('67', '2025-04-29', '2025-05-15', '2025-06-26', '2680000000000000', 6);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('68', '2025-04-29', '2025-05-14', '2025-06-10', '7070000000000000', 8);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('69', '2025-01-30', '2025-02-05', '2025-03-01', '4850000000000000', 7);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('70', '2025-04-29', '2025-05-07', '2025-07-04', '9840000000000000', 6);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('71', '2025-02-27', '2025-03-29', '2025-04-23', '4450000000000000', 1);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('72', '2025-01-30', '2025-02-18', '2025-03-19', '6250000000000000', 2);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('73', '2025-04-29', '2025-05-16', '2025-07-11', '3130000000000000', 10);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('74', '2025-12-30', '2026-01-14', '2026-03-14', '4650000000000000', 3);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('75', '2025-12-30', '2026-01-24', '2026-03-24', '2060000000000000', 6);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('76', '2025-03-30', '2025-04-28', '2025-05-23', '9620000000000000', 1);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('77', '2025-12-30', '2026-01-14', '2026-02-08', '4750000000000000', 1);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('78', '2025-05-30', '2025-06-10', '2025-06-16', '6980000000000000', 7);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('79', '2025-02-27', '2025-03-24', '2025-05-07', '8090000000000000', 4);
INSERT INTO Orders (Order_ID, Order_Date, Dep_Date, Arriv_Date, Credit_Card_Number, Payments) VALUES ('80', '2025-04-29', '2025-05-15', '2025-06-27', '9260000000000000', 4);


--health status
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('1', '1', '1000000000', 0, 0, 1, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('1', '2', '1000000160', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('1', '3', '1000000080', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('2', '1', '1000000081', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('2', '2', '1000000161', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('2', '3', '1000000001', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('3', '1', '1000000162', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('3', '2', '1000000082', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('3', '3', '1000000002', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('4', '1', '1000000163', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('4', '2', '1000000003', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('4', '3', '1000000083', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('5', '1', '1000000004', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('5', '2', '1000000164', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('5', '3', '1000000084', 0, 1, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('6', '1', '1000000085', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('6', '2', '1000000005', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('6', '3', '1000000165', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('7', '1', '1000000086', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('7', '2', '1000000006', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('7', '3', '1000000166', 1, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('8', '1', '1000000007', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('8', '2', '1000000167', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('8', '3', '1000000087', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('9', '1', '1000000088', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('9', '2', '1000000168', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('9', '3', '1000000008', 1, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('10', '1', '1000000169', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('10', '2', '1000000009', 0, 0, 1, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('10', '3', '1000000089', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('11', '1', '1000000170', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('11', '2', '1000000010', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('11', '3', '1000000090', 0, 0, 1, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('12', '1', '1000000171', 0, 1, 1, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('12', '2', '1000000011', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('12', '3', '1000000091', 0, 0, 1, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('13', '1', '1000000012', 0, 1, 1, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('13', '2', '1000000092', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('13', '3', '1000000172', 1, 1, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('14', '1', '1000000173', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('14', '2', '1000000093', 1, 1, 1, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('14', '3', '1000000013', 0, 0, 1, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('15', '1', '1000000094', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('15', '2', '1000000174', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('15', '3', '1000000014', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('16', '1', '1000000095', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('16', '2', '1000000015', 0, 0, 0, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('16', '3', '1000000175', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('17', '1', '1000000096', 1, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('17', '2', '1000000016', 0, 0, 1, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('17', '3', '1000000176', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('18', '1', '1000000097', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('18', '2', '1000000017', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('18', '3', '1000000177', 0, 0, 1, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('19', '1', '1000000098', 0, 0, 1, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('19', '2', '1000000018', 1, 1, 1, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('19', '3', '1000000178', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('20', '1', '1000000179', 1, 1, 1, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('20', '2', '1000000099', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('20', '3', '1000000019', 0, 0, 0, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('21', '1', '1000000180', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('21', '2', '1000000020', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('21', '3', '1000000100', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('22', '1', '1000000101', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('22', '2', '1000000181', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('22', '3', '1000000021', 1, 1, 1, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('23', '1', '1000000182', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('23', '2', '1000000022', 0, 0, 1, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('23', '3', '1000000102', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('24', '1', '1000000183', 0, 1, 1, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('24', '2', '1000000103', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('24', '3', '1000000023', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('25', '1', '1000000104', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('25', '2', '1000000024', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('25', '3', '1000000184', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('26', '1', '1000000025', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('26', '2', '1000000185', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('26', '3', '1000000105', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('27', '1', '1000000186', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('27', '2', '1000000106', 1, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('27', '3', '1000000026', 0, 1, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('28', '1', '1000000187', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('28', '2', '1000000107', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('28', '3', '1000000027', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('29', '1', '1000000188', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('29', '2', '1000000108', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('29', '3', '1000000028', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('30', '1', '1000000029', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('30', '2', '1000000189', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('30', '3', '1000000109', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('31', '1', '1000000110', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('31', '2', '1000000190', 0, 0, 0, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('31', '3', '1000000030', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('32', '1', '1000000191', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('32', '2', '1000000111', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('32', '3', '1000000031', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('33', '1', '1000000032', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('33', '2', '1000000112', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('33', '3', '1000000192', 0, 0, 0, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('34', '1', '1000000113', 1, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('34', '2', '1000000033', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('34', '3', '1000000193', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('35', '1', '1000000114', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('35', '2', '1000000034', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('35', '3', '1000000194', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('36', '1', '1000000035', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('36', '2', '1000000195', 0, 0, 0, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('36', '3', '1000000115', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('37', '1', '1000000036', 1, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('37', '2', '1000000196', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('37', '3', '1000000116', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('38', '1', '1000000117', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('38', '2', '1000000037', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('38', '3', '1000000197', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('39', '1', '1000000118', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('39', '2', '1000000198', 0, 0, 0, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('39', '3', '1000000038', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('40', '1', '1000000119', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('40', '2', '1000000199', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('40', '3', '1000000039', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('41', '1', '1000000120', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('41', '2', '1000000040', 1, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('42', '1', '1000000041', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('42', '2', '1000000121', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('43', '1', '1000000042', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('43', '2', '1000000122', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('44', '1', '1000000123', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('44', '2', '1000000043', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('45', '1', '1000000124', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('45', '2', '1000000044', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('46', '1', '1000000125', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('46', '2', '1000000045', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('47', '1', '1000000126', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('47', '2', '1000000046', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('48', '1', '1000000127', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('48', '2', '1000000047', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('49', '1', '1000000048', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('49', '2', '1000000128', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('50', '1', '1000000129', 0, 1, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('50', '2', '1000000049', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('51', '1', '1000000050', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('51', '2', '1000000130', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('52', '1', '1000000051', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('52', '2', '1000000131', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('53', '1', '1000000052', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('53', '2', '1000000132', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('54', '1', '1000000053', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('54', '2', '1000000133', 0, 0, 0, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('55', '1', '1000000054', 1, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('55', '2', '1000000134', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('56', '1', '1000000135', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('56', '2', '1000000055', 1, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('57', '1', '1000000056', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('57', '2', '1000000136', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('58', '1', '1000000137', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('58', '2', '1000000057', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('59', '1', '1000000058', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('59', '2', '1000000138', 0, 0, 1, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('60', '1', '1000000139', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('60', '2', '1000000059', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('61', '1', '1000000060', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('61', '2', '1000000140', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('62', '1', '1000000061', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('62', '2', '1000000141', 1, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('63', '1', '1000000062', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('63', '2', '1000000142', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('64', '1', '1000000063', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('64', '2', '1000000143', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('65', '1', '1000000144', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('65', '2', '1000000064', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('66', '1', '1000000065', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('66', '2', '1000000145', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('67', '1', '1000000066', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('67', '2', '1000000146', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('68', '1', '1000000067', 0, 0, 1, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('68', '2', '1000000147', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('69', '1', '1000000068', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('69', '2', '1000000148', 1, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('70', '1', '1000000069', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('70', '2', '1000000149', 0, 0, 1, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('71', '1', '1000000150', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('71', '2', '1000000070', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('72', '1', '1000000071', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('72', '2', '1000000151', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('73', '1', '1000000152', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('73', '2', '1000000072', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('74', '1', '1000000073', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('74', '2', '1000000153', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('75', '1', '1000000154', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('75', '2', '1000000074', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('76', '1', '1000000155', 0, 0, 1, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('76', '2', '1000000075', 0, 0, 0, 1);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('77', '1', '1000000076', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('77', '2', '1000000156', 1, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('78', '1', '1000000077', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('78', '2', '1000000157', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('79', '1', '1000000078', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('79', '2', '1000000158', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('80', '1', '1000000079', 0, 0, 0, 0);
INSERT INTO Health_Status (Order_ID, Health_Status_ID, ID, Question_1, Question_2, Question_3, Question_4) VALUES ('80', '2', '1000000159', 0, 0, 0, 0);


--insurance

INSERT INTO Insurance (insurance_id, insur_type) VALUES ('1', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('2', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('3', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('4', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('5', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('6', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('7', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('8', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('9', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('10', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('11', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('12', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('13', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('14', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('15', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('16', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('17', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('18', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('19', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('20', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('21', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('22', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('23', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('24', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('25', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('26', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('27', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('28', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('29', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('30', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('31', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('32', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('33', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('34', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('35', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('36', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('37', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('38', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('39', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('40', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('41', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('42', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('43', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('44', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('45', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('46', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('47', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('48', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('49', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('50', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('51', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('52', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('53', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('54', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('55', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('56', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('57', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('58', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('59', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('60', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('61', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('62', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('63', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('64', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('65', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('66', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('67', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('68', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('69', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('70', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('71', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('72', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('73', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('74', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('75', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('76', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('77', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('78', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('79', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('80', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('81', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('82', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('83', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('84', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('85', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('86', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('87', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('88', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('89', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('90', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('91', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('92', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('93', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('94', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('95', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('96', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('97', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('98', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('99', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('100', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('101', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('102', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('103', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('104', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('105', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('106', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('107', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('108', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('109', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('110', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('111', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('112', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('113', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('114', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('115', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('116', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('117', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('118', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('119', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('120', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('121', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('122', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('123', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('124', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('125', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('126', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('127', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('128', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('129', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('130', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('131', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('132', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('133', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('134', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('135', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('136', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('137', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('138', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('139', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('140', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('141', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('142', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('143', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('144', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('145', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('146', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('147', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('148', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('149', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('150', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('151', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('152', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('153', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('154', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('155', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('156', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('157', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('158', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('159', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('160', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('161', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('162', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('163', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('164', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('165', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('166', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('167', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('168', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('169', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('170', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('171', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('172', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('173', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('174', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('175', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('176', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('177', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('178', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('179', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('180', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('181', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('182', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('183', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('184', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('185', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('186', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('187', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('188', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('189', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('190', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('191', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('192', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('193', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('194', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('195', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('196', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('197', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('198', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('199', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('200', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('201', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('202', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('203', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('204', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('205', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('206', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('207', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('208', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('209', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('210', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('211', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('212', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('213', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('214', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('215', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('216', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('217', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('218', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('219', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('220', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('221', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('222', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('223', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('224', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('225', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('226', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('227', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('228', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('229', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('230', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('231', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('232', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('233', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('234', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('235', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('236', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('237', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('238', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('239', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('240', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('241', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('242', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('243', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('244', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('245', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('246', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('247', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('248', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('249', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('250', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('251', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('252', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('253', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('254', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('255', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('256', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('257', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('258', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('259', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('260', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('261', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('262', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('263', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('264', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('265', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('266', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('267', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('268', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('269', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('270', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('271', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('272', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('273', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('274', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('275', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('276', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('277', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('278', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('279', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('280', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('281', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('282', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('283', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('284', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('285', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('286', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('287', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('288', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('289', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('290', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('291', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('292', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('293', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('294', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('295', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('296', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('297', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('298', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('299', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('300', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('301', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('302', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('303', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('304', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('305', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('306', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('307', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('308', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('309', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('310', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('311', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('312', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('313', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('314', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('315', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('316', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('317', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('318', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('319', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('320', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('321', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('322', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('323', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('324', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('325', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('326', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('327', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('328', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('329', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('330', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('331', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('332', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('333', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('334', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('335', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('336', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('337', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('338', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('339', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('340', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('341', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('342', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('343', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('344', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('345', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('346', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('347', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('348', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('349', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('350', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('351', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('352', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('353', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('354', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('355', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('356', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('357', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('358', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('359', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('360', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('361', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('362', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('363', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('364', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('365', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('366', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('367', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('368', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('369', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('370', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('371', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('372', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('373', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('374', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('375', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('376', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('377', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('378', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('379', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('380', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('381', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('382', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('383', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('384', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('385', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('386', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('387', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('388', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('389', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('390', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('391', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('392', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('393', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('394', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('395', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('396', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('397', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('398', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('399', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('400', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('401', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('402', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('403', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('404', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('405', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('406', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('407', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('408', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('409', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('410', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('411', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('412', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('413', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('414', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('415', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('416', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('417', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('418', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('419', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('420', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('421', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('422', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('423', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('424', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('425', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('426', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('427', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('428', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('429', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('430', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('431', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('432', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('433', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('434', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('435', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('436', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('437', 'Sport (Competitive)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('438', 'Experience Card or Event');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('439', 'Rental Car (Private)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('440', 'Rental Car (Jeep/Van)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('441', 'Camera');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('442', 'Medical Expenses in Israel');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('443', 'Search and Rescue');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('444', 'Trip Cancellation/Shortening');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('445', 'Baggage');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('446', 'Mobile Phone');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('447', 'Laptop or Tablet');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('448', 'Sport (Adventurous)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('449', 'sport (Winter)');
INSERT INTO Insurance (insurance_id, insur_type) VALUES ('450', 'Sport (Competitive)');

INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('4', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('5', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('6', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('7', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('8', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('9', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('10', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('11', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('12', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('13', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('17', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('18', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('19', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('20', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('21', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('22', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('23', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('24', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('25', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('26', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('30', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('31', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('32', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('33', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('34', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('35', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('36', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('37', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('38', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('39', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('43', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('44', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('45', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('46', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('47', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('48', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('49', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('50', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('51', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('52', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('56', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('57', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('58', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('59', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('60', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('61', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('62', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('63', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('64', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('65', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('69', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('70', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('71', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('72', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('73', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('74', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('75', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('76', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('77', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('78', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('82', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('83', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('84', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('85', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('86', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('87', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('88', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('89', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('90', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('91', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('95', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('96', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('97', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('98', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('99', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('100', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('101', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('102', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('103', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('104', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('108', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('109', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('110', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('111', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('112', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('113', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('114', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('115', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('116', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('117', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('121', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('122', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('123', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('124', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('125', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('126', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('127', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('128', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('129', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('130', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('134', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('135', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('136', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('137', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('138', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('139', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('140', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('141', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('142', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('143', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('147', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('148', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('149', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('150', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('151', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('152', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('153', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('154', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('155', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('156', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('160', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('161', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('162', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('163', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('164', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('165', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('166', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('167', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('168', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('169', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('173', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('174', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('175', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('176', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('177', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('178', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('179', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('180', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('181', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('182', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('186', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('187', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('188', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('189', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('190', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('191', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('192', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('193', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('194', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('195', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('199', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('200', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('201', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('202', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('203', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('204', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('205', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('206', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('207', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('208', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('212', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('213', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('214', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('215', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('216', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('217', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('218', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('219', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('220', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('221', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('225', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('226', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('227', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('228', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('229', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('230', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('231', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('232', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('233', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('234', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('238', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('239', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('240', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('241', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('242', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('243', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('244', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('245', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('246', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('247', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('251', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('252', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('253', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('254', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('255', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('256', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('257', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('258', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('259', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('260', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('264', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('265', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('266', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('267', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('268', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('269', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('270', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('271', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('272', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('273', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('277', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('278', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('279', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('280', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('281', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('282', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('283', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('284', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('285', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('286', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('290', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('291', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('292', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('293', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('294', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('295', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('296', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('297', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('298', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('299', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('303', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('304', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('305', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('306', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('307', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('308', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('309', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('310', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('311', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('312', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('316', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('317', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('318', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('319', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('320', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('321', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('322', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('323', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('324', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('325', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('329', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('330', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('331', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('332', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('333', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('334', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('335', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('336', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('337', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('338', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('342', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('343', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('344', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('345', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('346', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('347', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('348', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('349', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('350', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('351', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('355', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('356', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('357', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('358', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('359', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('360', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('361', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('362', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('363', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('364', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('368', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('369', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('370', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('371', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('372', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('373', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('374', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('375', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('376', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('377', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('381', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('382', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('383', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('384', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('385', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('386', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('387', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('388', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('389', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('390', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('394', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('395', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('396', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('397', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('398', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('399', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('400', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('401', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('402', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('403', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('407', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('408', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('409', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('410', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('411', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('412', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('413', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('414', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('415', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('416', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('420', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('421', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('422', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('423', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('424', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('425', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('426', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('427', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('428', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('429', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('433', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('434', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('435', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('436', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('437', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('438', '2023-01-01', '2023-12-31', 'Event_Model_VIP');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('439', '2023-01-01', '2023-12-31', 'Car_Model_Sedan');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('440', '2023-01-01', '2023-12-31', 'Jeep_Model_Offroad');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('441', '2023-01-01', '2023-12-31', 'Camera_Model_DSLR');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('442', '2023-01-01', '2023-12-31', 'Medical_Model_Advanced');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('446', '2023-01-01', '2023-12-31', 'Phone_Model_Pro');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('447', '2023-01-01', '2023-12-31', 'Tablet_Model_Standard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('448', '2023-01-01', '2023-12-31', 'Adventure_Model_Outdoor');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('449', '2023-01-01', '2023-12-31', 'Winter_Model_Snowboard');
INSERT INTO Extra_Insurances (insurance_id, Starting_Date, End_Date, Model) VALUES ('450', '2023-01-01', '2023-12-31', 'Competitive_Model_Pro');


--cover
INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('1', '1',  '1000000000',  '1',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('2', '1',  '1000000160',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('3', '1',  '1000000080',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('4', '2',  '1000000081',  '1',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('5', '2',  '1000000161',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('6', '2',  '1000000001',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('7', '3',  '1000000162',  '1',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('8', '3',  '1000000082',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('9', '3',  '1000000002',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('10', '4',  '1000000163',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('11', '4',  '1000000003',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('12', '4',  '1000000083',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('13', '5',  '1000000004',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('14', '5',  '1000000164',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('15', '5',  '1000000084',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('16', '6',  '1000000085',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('17', '6',  '1000000005',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('18', '6',  '1000000165',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('19', '7',  '1000000086',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('20', '7',  '1000000006',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('21', '7',  '1000000166',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('22', '8',  '1000000007',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('23', '8',  '1000000167',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('24', '8',  '1000000087',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('25', '9',  '1000000088',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('26', '9',  '1000000168',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('27', '9',  '1000000008',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('28', '10',  '1000000169',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('29', '10',  '1000000009',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('30', '10',  '1000000089',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('31', '11',  '1000000170',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('32', '11',  '1000000010',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('33', '11',  '1000000090',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('34', '12',  '1000000171',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('35', '12',  '1000000011',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('36', '12',  '1000000091',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('37', '13',  '1000000012',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('38', '13',  '1000000092',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('39', '13',  '1000000172',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('40', '14',  '1000000173',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('41', '14',  '1000000093',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('42', '14',  '1000000013',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('43', '15',  '1000000094',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('44', '15',  '1000000174',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('45', '15',  '1000000014',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('46', '16',  '1000000095',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('47', '16',  '1000000015',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('48', '16',  '1000000175',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('49', '17',  '1000000096',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('50', '17',  '1000000016',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('51', '17',  '1000000176',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('52', '18',  '1000000097',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('53', '18',  '1000000017',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('54', '18',  '1000000177',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('55', '19',  '1000000098',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('56', '19',  '1000000018',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('57', '19',  '1000000178',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('58', '20',  '1000000179',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('59', '20',  '1000000099',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('60', '20',  '1000000019',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('61', '21',  '1000000180',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('62', '21',  '1000000020',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('63', '21',  '1000000100',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('64', '22',  '1000000101',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('65', '22',  '1000000181',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('66', '22',  '1000000021',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('67', '23',  '1000000182',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('68', '23',  '1000000022',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('69', '23',  '1000000102',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('70', '24',  '1000000183',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('71', '24',  '1000000103',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('72', '24',  '1000000023',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('73', '25',  '1000000104',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('74', '25',  '1000000024',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('75', '25',  '1000000184',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('76', '26',  '1000000025',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('77', '26',  '1000000185',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('78', '26',  '1000000105',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('79', '27',  '1000000186',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('80', '27',  '1000000106',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('81', '27',  '1000000026',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('82', '28',  '1000000187',  '1',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('83', '28',  '1000000107',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('84', '28',  '1000000027',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('85', '29',  '1000000188',  '1',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('86', '29',  '1000000108',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('87', '29',  '1000000028',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('88', '30',  '1000000029',  '1',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('89', '30',  '1000000189',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('90', '30',  '1000000109',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('91', '31',  '1000000110',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('92', '31',  '1000000190',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('93', '31',  '1000000030',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('94', '32',  '1000000191',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('95', '32',  '1000000111',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('96', '32',  '1000000031',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('97', '33',  '1000000032',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('98', '33',  '1000000112',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('99', '33',  '1000000192',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('100', '34',  '1000000113',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('101', '34',  '1000000033',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('102', '34',  '1000000193',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('103', '35',  '1000000114',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('104', '35',  '1000000034',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('105', '35',  '1000000194',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('106', '36',  '1000000035',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('107', '36',  '1000000195',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('108', '36',  '1000000115',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('109', '37',  '1000000036',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('110', '37',  '1000000196',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('111', '37',  '1000000116',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('112', '38',  '1000000117',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('113', '38',  '1000000037',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('114', '38',  '1000000197',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('115', '39',  '1000000118',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('116', '39',  '1000000198',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('117', '39',  '1000000038',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('118', '40',  '1000000119',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('119', '40',  '1000000199',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('120', '40',  '1000000039',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('121', '41',  '1000000120',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('122', '41',  '1000000040',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('123', '42',  '1000000041',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('124', '42',  '1000000121',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('125', '43',  '1000000042',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('126', '43',  '1000000122',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('127', '44',  '1000000123',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('128', '44',  '1000000043',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('129', '45',  '1000000124',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('130', '45',  '1000000044',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('131', '46',  '1000000125',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('132', '46',  '1000000045',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('133', '47',  '1000000126',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('134', '47',  '1000000046',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('135', '48',  '1000000127',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('136', '48',  '1000000047',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('137', '49',  '1000000048',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('138', '49',  '1000000128',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('139', '50',  '1000000129',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('140', '50',  '1000000049',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('141', '51',  '1000000050',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('142', '51',  '1000000130',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('143', '52',  '1000000051',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('144', '52',  '1000000131',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('145', '53',  '1000000052',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('146', '53',  '1000000132',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('147', '54',  '1000000053',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('148', '54',  '1000000133',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('149', '55',  '1000000054',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('150', '55',  '1000000134',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('151', '56',  '1000000135',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('152', '56',  '1000000055',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('153', '57',  '1000000056',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('154', '57',  '1000000136',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('155', '58',  '1000000137',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('156', '58',  '1000000057',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('157', '59',  '1000000058',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('158', '59',  '1000000138',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('159', '60',  '1000000139',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('160', '60',  '1000000059',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('161', '61',  '1000000060',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('162', '61',  '1000000140',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('163', '62',  '1000000061',  '1',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('164', '62',  '1000000141',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('165', '63',  '1000000062',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('166', '63',  '1000000142',  '2',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('167', '64',  '1000000063',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('168', '64',  '1000000143',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('169', '65',  '1000000144',  '1',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('170', '65',  '1000000064',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('171', '66',  '1000000065',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('172', '66',  '1000000145',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('173', '67',  '1000000066',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('174', '67',  '1000000146',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('175', '68',  '1000000067',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('176', '68',  '1000000147',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('177', '69',  '1000000068',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('178', '69',  '1000000148',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('179', '70',  '1000000069',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('180', '70',  '1000000149',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('181', '71',  '1000000150',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('182', '71',  '1000000070',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('183', '72',  '1000000071',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('184', '72',  '1000000151',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('185', '73',  '1000000152',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('186', '73',  '1000000072',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('187', '74',  '1000000073',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('188', '74',  '1000000153',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('189', '75',  '1000000154',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('190', '75',  '1000000074',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('191', '76',  '1000000155',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('192', '76',  '1000000075',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('193', '77',  '1000000076',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('194', '77',  '1000000156',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('195', '78',  '1000000077',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('196', '78',  '1000000157',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('197', '79',  '1000000078',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('198', '79',  '1000000158',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('199', '80',  '1000000079',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('200', '80',  '1000000159',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('201', '1',  '1000000000',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('202', '1',  '1000000160',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('203', '1',  '1000000080',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('204', '2',  '1000000081',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('205', '2',  '1000000161',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('206', '2',  '1000000001',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('207', '3',  '1000000162',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('208', '3',  '1000000082',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('209', '3',  '1000000002',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('210', '4',  '1000000163',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('211', '4',  '1000000003',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('212', '4',  '1000000083',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('213', '5',  '1000000004',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('214', '5',  '1000000164',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('215', '5',  '1000000084',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('216', '6',  '1000000085',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('217', '6',  '1000000005',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('218', '6',  '1000000165',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('219', '7',  '1000000086',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('220', '7',  '1000000006',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('221', '7',  '1000000166',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('222', '8',  '1000000007',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('223', '8',  '1000000167',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('224', '8',  '1000000087',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('225', '9',  '1000000088',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('226', '9',  '1000000168',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('227', '9',  '1000000008',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('228', '10',  '1000000169',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('229', '10',  '1000000009',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('230', '10',  '1000000089',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('231', '11',  '1000000170',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('232', '11',  '1000000010',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('233', '11',  '1000000090',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('234', '12',  '1000000171',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('235', '12',  '1000000011',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('236', '12',  '1000000091',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('237', '13',  '1000000012',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('238', '13',  '1000000092',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('239', '13',  '1000000172',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('240', '14',  '1000000173',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('241', '14',  '1000000093',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('242', '14',  '1000000013',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('243', '15',  '1000000094',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('244', '15',  '1000000174',  '2',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('245', '15',  '1000000014',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('246', '16',  '1000000095',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('247', '16',  '1000000015',  '2',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('248', '16',  '1000000175',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('249', '17',  '1000000096',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('250', '17',  '1000000016',  '2',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('251', '17',  '1000000176',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('252', '18',  '1000000097',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('253', '18',  '1000000017',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('254', '18',  '1000000177',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('255', '19',  '1000000098',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('256', '19',  '1000000018',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('257', '19',  '1000000178',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('258', '20',  '1000000179',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('259', '20',  '1000000099',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('260', '20',  '1000000019',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('261', '21',  '1000000180',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('262', '21',  '1000000020',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('263', '21',  '1000000100',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('264', '22',  '1000000101',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('265', '22',  '1000000181',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('266', '22',  '1000000021',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('267', '23',  '1000000182',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('268', '23',  '1000000022',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('269', '23',  '1000000102',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('270', '24',  '1000000183',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('271', '24',  '1000000103',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('272', '24',  '1000000023',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('273', '25',  '1000000104',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('274', '25',  '1000000024',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('275', '25',  '1000000184',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('276', '26',  '1000000025',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('277', '26',  '1000000185',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('278', '26',  '1000000105',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('279', '27',  '1000000186',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('280', '27',  '1000000106',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('281', '27',  '1000000026',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('282', '28',  '1000000187',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('283', '28',  '1000000107',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('284', '28',  '1000000027',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('285', '29',  '1000000188',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('286', '29',  '1000000108',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('287', '29',  '1000000028',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('288', '30',  '1000000029',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('289', '30',  '1000000189',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('290', '30',  '1000000109',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('291', '31',  '1000000110',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('292', '31',  '1000000190',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('293', '31',  '1000000030',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('294', '32',  '1000000191',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('295', '32',  '1000000111',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('296', '32',  '1000000031',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('297', '33',  '1000000032',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('298', '33',  '1000000112',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('299', '33',  '1000000192',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('300', '34',  '1000000113',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('301', '34',  '1000000033',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('302', '34',  '1000000193',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('303', '35',  '1000000114',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('304', '35',  '1000000034',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('305', '35',  '1000000194',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('306', '36',  '1000000035',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('307', '36',  '1000000195',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('308', '36',  '1000000115',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('309', '37',  '1000000036',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('310', '37',  '1000000196',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('311', '37',  '1000000116',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('312', '38',  '1000000117',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('313', '38',  '1000000037',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('314', '38',  '1000000197',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('315', '39',  '1000000118',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('316', '39',  '1000000198',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('317', '39',  '1000000038',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('318', '40',  '1000000119',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('319', '40',  '1000000199',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('320', '40',  '1000000039',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('321', '41',  '1000000120',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('322', '41',  '1000000040',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('323', '42',  '1000000041',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('324', '42',  '1000000121',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('325', '43',  '1000000042',  '1',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('326', '43',  '1000000122',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('327', '44',  '1000000123',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('328', '44',  '1000000043',  '2',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('329', '45',  '1000000124',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('330', '45',  '1000000044',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('331', '46',  '1000000125',  '1',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('332', '46',  '1000000045',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('333', '47',  '1000000126',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('334', '47',  '1000000046',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('335', '48',  '1000000127',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('336', '48',  '1000000047',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('337', '49',  '1000000048',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('338', '49',  '1000000128',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('339', '50',  '1000000129',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('340', '50',  '1000000049',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('341', '51',  '1000000050',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('342', '51',  '1000000130',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('343', '52',  '1000000051',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('344', '52',  '1000000131',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('345', '53',  '1000000052',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('346', '53',  '1000000132',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('347', '54',  '1000000053',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('348', '54',  '1000000133',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('349', '55',  '1000000054',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('350', '55',  '1000000134',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('351', '56',  '1000000135',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('352', '56',  '1000000055',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('353', '57',  '1000000056',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('354', '57',  '1000000136',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('355', '58',  '1000000137',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('356', '58',  '1000000057',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('357', '59',  '1000000058',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('358', '59',  '1000000138',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('359', '60',  '1000000139',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('360', '60',  '1000000059',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('361', '61',  '1000000060',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('362', '61',  '1000000140',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('363', '62',  '1000000061',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('364', '62',  '1000000141',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('365', '63',  '1000000062',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('366', '63',  '1000000142',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('367', '64',  '1000000063',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('368', '64',  '1000000143',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('369', '65',  '1000000144',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('370', '65',  '1000000064',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('371', '66',  '1000000065',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('372', '66',  '1000000145',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('373', '67',  '1000000066',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('374', '67',  '1000000146',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('375', '68',  '1000000067',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('376', '68',  '1000000147',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('377', '69',  '1000000068',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('378', '69',  '1000000148',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('379', '70',  '1000000069',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('380', '70',  '1000000149',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('381', '71',  '1000000150',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('382', '71',  '1000000070',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('383', '72',  '1000000071',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('384', '72',  '1000000151',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('385', '73',  '1000000152',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('386', '73',  '1000000072',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('387', '74',  '1000000073',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('388', '74',  '1000000153',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('389', '75',  '1000000154',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('390', '75',  '1000000074',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('391', '76',  '1000000155',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('392', '76',  '1000000075',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('393', '77',  '1000000076',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('394', '77',  '1000000156',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('395', '78',  '1000000077',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('396', '78',  '1000000157',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('397', '79',  '1000000078',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('398', '79',  '1000000158',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('399', '80',  '1000000079',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('400', '80',  '1000000159',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('401', '1',  '1000000000',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('402', '1',  '1000000160',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('403', '1',  '1000000080',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('404', '2',  '1000000081',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('405', '2',  '1000000161',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('406', '2',  '1000000001',  '3',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('407', '3',  '1000000162',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('408', '3',  '1000000082',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('409', '3',  '1000000002',  '3',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('410', '4',  '1000000163',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('411', '4',  '1000000003',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('412', '4',  '1000000083',  '3',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('413', '5',  '1000000004',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('414', '5',  '1000000164',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('415', '5',  '1000000084',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('416', '6',  '1000000085',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('417', '6',  '1000000005',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('418', '6',  '1000000165',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('419', '7',  '1000000086',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('420', '7',  '1000000006',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('421', '7',  '1000000166',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('422', '8',  '1000000007',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('423', '8',  '1000000167',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('424', '8',  '1000000087',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('425', '9',  '1000000088',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('426', '9',  '1000000168',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('427', '9',  '1000000008',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('428', '10',  '1000000169',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('429', '10',  '1000000009',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('430', '10',  '1000000089',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('431', '11',  '1000000170',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('432', '11',  '1000000010',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('433', '11',  '1000000090',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('434', '12',  '1000000171',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('435', '12',  '1000000011',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('436', '12',  '1000000091',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('437', '13',  '1000000012',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('438', '13',  '1000000092',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('439', '13',  '1000000172',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('440', '14',  '1000000173',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('441', '14',  '1000000093',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('442', '14',  '1000000013',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('443', '15',  '1000000094',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('444', '15',  '1000000174',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('445', '15',  '1000000014',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('446', '16',  '1000000095',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('447', '16',  '1000000015',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('448', '16',  '1000000175',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('449', '17',  '1000000096',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES ('450', '17',  '1000000016',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '17',  '1000000176',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000097',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000017',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000177',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000098',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000018',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000178',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000179',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000099',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000019',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000180',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000020',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000100',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000101',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000181',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000021',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000182',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000022',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000102',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000183',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000103',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000023',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000104',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000024',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000184',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000025',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000185',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000105',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000186',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000106',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000026',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '28',  '1000000187',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '28',  '1000000107',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '28',  '1000000027',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '29',  '1000000188',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '29',  '1000000108',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '29',  '1000000028',  '3',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '30',  '1000000029',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '30',  '1000000189',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '30',  '1000000109',  '3',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '31',  '1000000110',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '31',  '1000000190',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '31',  '1000000030',  '3',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '32',  '1000000191',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '32',  '1000000111',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '32',  '1000000031',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '33',  '1000000032',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '33',  '1000000112',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '33',  '1000000192',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '34',  '1000000113',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '34',  '1000000033',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '34',  '1000000193',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '35',  '1000000114',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '35',  '1000000034',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '35',  '1000000194',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '36',  '1000000035',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '36',  '1000000195',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '36',  '1000000115',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '37',  '1000000036',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '37',  '1000000196',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '37',  '1000000116',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '38',  '1000000117',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '38',  '1000000037',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '38',  '1000000197',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '39',  '1000000118',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '39',  '1000000198',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '39',  '1000000038',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '40',  '1000000119',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '40',  '1000000199',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '40',  '1000000039',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '41',  '1000000120',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '41',  '1000000040',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '42',  '1000000041',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '42',  '1000000121',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '43',  '1000000042',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '43',  '1000000122',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '44',  '1000000123',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '44',  '1000000043',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '45',  '1000000124',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '45',  '1000000044',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '46',  '1000000125',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '46',  '1000000045',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '47',  '1000000126',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '47',  '1000000046',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '48',  '1000000127',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '48',  '1000000047',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '49',  '1000000048',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '49',  '1000000128',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '50',  '1000000129',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '50',  '1000000049',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '51',  '1000000050',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '51',  '1000000130',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '52',  '1000000051',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '52',  '1000000131',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '53',  '1000000052',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '53',  '1000000132',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '54',  '1000000053',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '54',  '1000000133',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '55',  '1000000054',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '55',  '1000000134',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '56',  '1000000135',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '56',  '1000000055',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '57',  '1000000056',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '57',  '1000000136',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '58',  '1000000137',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '58',  '1000000057',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '59',  '1000000058',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '59',  '1000000138',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '60',  '1000000139',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '60',  '1000000059',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '61',  '1000000060',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '61',  '1000000140',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '62',  '1000000061',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '62',  '1000000141',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '63',  '1000000062',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '63',  '1000000142',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '64',  '1000000063',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '64',  '1000000143',  '2',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '65',  '1000000144',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '65',  '1000000064',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '66',  '1000000065',  '1',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '66',  '1000000145',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '67',  '1000000066',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '67',  '1000000146',  '2',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '68',  '1000000067',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '68',  '1000000147',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '69',  '1000000068',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '69',  '1000000148',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '70',  '1000000069',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '70',  '1000000149',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '71',  '1000000150',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '71',  '1000000070',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '72',  '1000000071',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '72',  '1000000151',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '73',  '1000000152',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '73',  '1000000072',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '74',  '1000000073',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '74',  '1000000153',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '75',  '1000000154',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '75',  '1000000074',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '76',  '1000000155',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '76',  '1000000075',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '77',  '1000000076',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '77',  '1000000156',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '78',  '1000000077',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '78',  '1000000157',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '79',  '1000000078',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '79',  '1000000158',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '80',  '1000000079',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '80',  '1000000159',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '1',  '1000000000',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '1',  '1000000160',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '1',  '1000000080',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '2',  '1000000081',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '2',  '1000000161',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '2',  '1000000001',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '3',  '1000000162',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '3',  '1000000082',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '3',  '1000000002',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '4',  '1000000163',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '4',  '1000000003',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '4',  '1000000083',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '5',  '1000000004',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '5',  '1000000164',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '5',  '1000000084',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '6',  '1000000085',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '6',  '1000000005',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '6',  '1000000165',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '7',  '1000000086',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '7',  '1000000006',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '7',  '1000000166',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '8',  '1000000007',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '8',  '1000000167',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '8',  '1000000087',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '9',  '1000000088',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '9',  '1000000168',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '9',  '1000000008',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '10',  '1000000169',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '10',  '1000000009',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '10',  '1000000089',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '11',  '1000000170',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '11',  '1000000010',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '11',  '1000000090',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '12',  '1000000171',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '12',  '1000000011',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '12',  '1000000091',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '13',  '1000000012',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '13',  '1000000092',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '13',  '1000000172',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '14',  '1000000173',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '14',  '1000000093',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '14',  '1000000013',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '15',  '1000000094',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '15',  '1000000174',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '15',  '1000000014',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '16',  '1000000095',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '16',  '1000000015',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '16',  '1000000175',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '17',  '1000000096',  '1',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '17',  '1000000016',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '17',  '1000000176',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000097',  '1',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000017',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000177',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000098',  '1',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000018',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000178',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000179',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000099',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000019',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000180',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000020',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000100',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000101',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000181',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000021',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000182',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000022',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000102',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000183',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000103',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000023',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000104',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000024',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000184',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000025',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000185',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000105',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000186',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000106',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000026',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '28',  '1000000187',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '28',  '1000000107',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '28',  '1000000027',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '29',  '1000000188',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '29',  '1000000108',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '29',  '1000000028',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '30',  '1000000029',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '30',  '1000000189',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '30',  '1000000109',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '31',  '1000000110',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '31',  '1000000190',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '31',  '1000000030',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '32',  '1000000191',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '32',  '1000000111',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '32',  '1000000031',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '33',  '1000000032',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '33',  '1000000112',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '33',  '1000000192',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '34',  '1000000113',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '34',  '1000000033',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '34',  '1000000193',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '35',  '1000000114',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '35',  '1000000034',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '35',  '1000000194',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '36',  '1000000035',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '36',  '1000000195',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '36',  '1000000115',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '37',  '1000000036',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '37',  '1000000196',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '37',  '1000000116',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '38',  '1000000117',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '38',  '1000000037',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '38',  '1000000197',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '39',  '1000000118',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '39',  '1000000198',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '39',  '1000000038',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '40',  '1000000119',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '40',  '1000000199',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '40',  '1000000039',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '41',  '1000000120',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '41',  '1000000040',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '42',  '1000000041',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '42',  '1000000121',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '43',  '1000000042',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '43',  '1000000122',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '44',  '1000000123',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '44',  '1000000043',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '45',  '1000000124',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '45',  '1000000044',  '2',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '46',  '1000000125',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '46',  '1000000045',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '47',  '1000000126',  '1',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '47',  '1000000046',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '48',  '1000000127',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '48',  '1000000047',  '2',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '49',  '1000000048',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '49',  '1000000128',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '50',  '1000000129',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '50',  '1000000049',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '51',  '1000000050',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '51',  '1000000130',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '52',  '1000000051',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '52',  '1000000131',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '53',  '1000000052',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '53',  '1000000132',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '54',  '1000000053',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '54',  '1000000133',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '55',  '1000000054',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '55',  '1000000134',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '56',  '1000000135',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '56',  '1000000055',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '57',  '1000000056',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '57',  '1000000136',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '58',  '1000000137',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '58',  '1000000057',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '59',  '1000000058',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '59',  '1000000138',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '60',  '1000000139',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '60',  '1000000059',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '61',  '1000000060',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '61',  '1000000140',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '62',  '1000000061',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '62',  '1000000141',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '63',  '1000000062',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '63',  '1000000142',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '64',  '1000000063',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '64',  '1000000143',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '65',  '1000000144',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '65',  '1000000064',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '66',  '1000000065',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '66',  '1000000145',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '67',  '1000000066',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '67',  '1000000146',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '68',  '1000000067',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '68',  '1000000147',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '69',  '1000000068',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '69',  '1000000148',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '70',  '1000000069',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '70',  '1000000149',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '71',  '1000000150',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '71',  '1000000070',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '72',  '1000000071',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '72',  '1000000151',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '73',  '1000000152',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '73',  '1000000072',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '74',  '1000000073',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '74',  '1000000153',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '75',  '1000000154',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '75',  '1000000074',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '76',  '1000000155',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '76',  '1000000075',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '77',  '1000000076',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '77',  '1000000156',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '78',  '1000000077',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '78',  '1000000157',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '79',  '1000000078',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '79',  '1000000158',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '80',  '1000000079',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '80',  '1000000159',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '1',  '1000000000',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '1',  '1000000160',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '1',  '1000000080',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '2',  '1000000081',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '2',  '1000000161',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '2',  '1000000001',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '3',  '1000000162',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '3',  '1000000082',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '3',  '1000000002',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '4',  '1000000163',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '4',  '1000000003',  '2',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '4',  '1000000083',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '5',  '1000000004',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '5',  '1000000164',  '2',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '5',  '1000000084',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '6',  '1000000085',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '6',  '1000000005',  '2',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '6',  '1000000165',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '7',  '1000000086',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '7',  '1000000006',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '7',  '1000000166',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '8',  '1000000007',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '8',  '1000000167',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '8',  '1000000087',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '9',  '1000000088',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '9',  '1000000168',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '9',  '1000000008',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '10',  '1000000169',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '10',  '1000000009',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '10',  '1000000089',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '11',  '1000000170',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '11',  '1000000010',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '11',  '1000000090',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '12',  '1000000171',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '12',  '1000000011',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '12',  '1000000091',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '13',  '1000000012',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '13',  '1000000092',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '13',  '1000000172',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '14',  '1000000173',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '14',  '1000000093',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '14',  '1000000013',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '15',  '1000000094',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '15',  '1000000174',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '15',  '1000000014',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '16',  '1000000095',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '16',  '1000000015',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '16',  '1000000175',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '17',  '1000000096',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '17',  '1000000016',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '17',  '1000000176',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000097',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000017',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000177',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000098',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000018',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000178',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000179',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000099',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000019',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000180',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000020',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000100',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000101',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000181',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000021',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000182',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000022',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000102',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000183',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000103',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000023',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000104',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000024',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000184',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000025',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000185',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000105',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000186',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000106',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000026',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '28',  '1000000187',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '28',  '1000000107',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '28',  '1000000027',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '29',  '1000000188',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '29',  '1000000108',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '29',  '1000000028',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '30',  '1000000029',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '30',  '1000000189',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '30',  '1000000109',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '31',  '1000000110',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '31',  '1000000190',  '2',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '31',  '1000000030',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '32',  '1000000191',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '32',  '1000000111',  '2',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '32',  '1000000031',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '33',  '1000000032',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '33',  '1000000112',  '2',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '33',  '1000000192',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '34',  '1000000113',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '34',  '1000000033',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '34',  '1000000193',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '35',  '1000000114',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '35',  '1000000034',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '35',  '1000000194',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '36',  '1000000035',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '36',  '1000000195',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '36',  '1000000115',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '37',  '1000000036',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '37',  '1000000196',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '37',  '1000000116',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '38',  '1000000117',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '38',  '1000000037',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '38',  '1000000197',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '39',  '1000000118',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '39',  '1000000198',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '39',  '1000000038',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '40',  '1000000119',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '40',  '1000000199',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '40',  '1000000039',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '41',  '1000000120',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '41',  '1000000040',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '42',  '1000000041',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '42',  '1000000121',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '43',  '1000000042',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '43',  '1000000122',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '44',  '1000000123',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '44',  '1000000043',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '45',  '1000000124',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '45',  '1000000044',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '46',  '1000000125',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '46',  '1000000045',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '47',  '1000000126',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '47',  '1000000046',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '48',  '1000000127',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '48',  '1000000047',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '49',  '1000000048',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '49',  '1000000128',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '50',  '1000000129',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '50',  '1000000049',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '51',  '1000000050',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '51',  '1000000130',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '52',  '1000000051',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '52',  '1000000131',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '53',  '1000000052',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '53',  '1000000132',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '54',  '1000000053',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '54',  '1000000133',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '55',  '1000000054',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '55',  '1000000134',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '56',  '1000000135',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '56',  '1000000055',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '57',  '1000000056',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '57',  '1000000136',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '58',  '1000000137',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '58',  '1000000057',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '59',  '1000000058',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '59',  '1000000138',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '60',  '1000000139',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '60',  '1000000059',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '61',  '1000000060',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '61',  '1000000140',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '62',  '1000000061',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '62',  '1000000141',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '63',  '1000000062',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '63',  '1000000142',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '64',  '1000000063',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '64',  '1000000143',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '65',  '1000000144',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '65',  '1000000064',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '66',  '1000000065',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '66',  '1000000145',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '67',  '1000000066',  '1',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '67',  '1000000146',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '68',  '1000000067',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '68',  '1000000147',  '2',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '69',  '1000000068',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '69',  '1000000148',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '70',  '1000000069',  '1',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '70',  '1000000149',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '71',  '1000000150',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '71',  '1000000070',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '72',  '1000000071',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '72',  '1000000151',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '73',  '1000000152',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '73',  '1000000072',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '74',  '1000000073',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '74',  '1000000153',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '75',  '1000000154',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '75',  '1000000074',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '76',  '1000000155',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '76',  '1000000075',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '77',  '1000000076',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '77',  '1000000156',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '78',  '1000000077',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '78',  '1000000157',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '79',  '1000000078',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '79',  '1000000158',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '80',  '1000000079',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '80',  '1000000159',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '1',  '1000000000',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '1',  '1000000160',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '1',  '1000000080',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '2',  '1000000081',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '2',  '1000000161',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '2',  '1000000001',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '3',  '1000000162',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '3',  '1000000082',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '3',  '1000000002',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '4',  '1000000163',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '4',  '1000000003',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '4',  '1000000083',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '5',  '1000000004',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '5',  '1000000164',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '5',  '1000000084',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '6',  '1000000085',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '6',  '1000000005',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '6',  '1000000165',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '7',  '1000000086',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '7',  '1000000006',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '7',  '1000000166',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '8',  '1000000007',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '8',  '1000000167',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '8',  '1000000087',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '9',  '1000000088',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '9',  '1000000168',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '9',  '1000000008',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '10',  '1000000169',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '10',  '1000000009',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '10',  '1000000089',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '11',  '1000000170',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '11',  '1000000010',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '11',  '1000000090',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '12',  '1000000171',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '12',  '1000000011',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '12',  '1000000091',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '13',  '1000000012',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '13',  '1000000092',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '13',  '1000000172',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '14',  '1000000173',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '14',  '1000000093',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '14',  '1000000013',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '15',  '1000000094',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '15',  '1000000174',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '15',  '1000000014',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '16',  '1000000095',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '16',  '1000000015',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '16',  '1000000175',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '17',  '1000000096',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '17',  '1000000016',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '17',  '1000000176',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000097',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000017',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000177',  '3',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000098',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000018',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000178',  '3',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000179',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000099',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000019',  '3',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000180',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000020',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000100',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000101',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000181',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000021',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000182',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000022',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000102',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000183',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000103',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000023',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000104',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000024',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000184',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000025',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000185',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000105',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000186',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000106',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000026',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '28',  '1000000187',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '28',  '1000000107',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '28',  '1000000027',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '29',  '1000000188',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '29',  '1000000108',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '29',  '1000000028',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '30',  '1000000029',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '30',  '1000000189',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '30',  '1000000109',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '31',  '1000000110',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '31',  '1000000190',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '31',  '1000000030',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '32',  '1000000191',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '32',  '1000000111',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '32',  '1000000031',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '33',  '1000000032',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '33',  '1000000112',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '33',  '1000000192',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '34',  '1000000113',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '34',  '1000000033',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '34',  '1000000193',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '35',  '1000000114',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '35',  '1000000034',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '35',  '1000000194',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '36',  '1000000035',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '36',  '1000000195',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '36',  '1000000115',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '37',  '1000000036',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '37',  '1000000196',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '37',  '1000000116',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '38',  '1000000117',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '38',  '1000000037',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '38',  '1000000197',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '39',  '1000000118',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '39',  '1000000198',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '39',  '1000000038',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '40',  '1000000119',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '40',  '1000000199',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '40',  '1000000039',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '41',  '1000000120',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '41',  '1000000040',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '42',  '1000000041',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '42',  '1000000121',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '43',  '1000000042',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '43',  '1000000122',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '44',  '1000000123',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '44',  '1000000043',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '45',  '1000000124',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '45',  '1000000044',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '46',  '1000000125',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '46',  '1000000045',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '47',  '1000000126',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '47',  '1000000046',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '48',  '1000000127',  '1',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '48',  '1000000047',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '49',  '1000000048',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '49',  '1000000128',  '2',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '50',  '1000000129',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '50',  '1000000049',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '51',  '1000000050',  '1',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '51',  '1000000130',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '52',  '1000000051',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '52',  '1000000131',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '53',  '1000000052',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '53',  '1000000132',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '54',  '1000000053',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '54',  '1000000133',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '55',  '1000000054',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '55',  '1000000134',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '56',  '1000000135',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '56',  '1000000055',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '57',  '1000000056',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '57',  '1000000136',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '58',  '1000000137',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '58',  '1000000057',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '59',  '1000000058',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '59',  '1000000138',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '60',  '1000000139',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '60',  '1000000059',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '61',  '1000000060',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '61',  '1000000140',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '62',  '1000000061',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '62',  '1000000141',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '63',  '1000000062',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '63',  '1000000142',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '64',  '1000000063',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '64',  '1000000143',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '65',  '1000000144',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '65',  '1000000064',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '66',  '1000000065',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '66',  '1000000145',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '67',  '1000000066',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '67',  '1000000146',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '68',  '1000000067',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '68',  '1000000147',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '69',  '1000000068',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '69',  '1000000148',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '70',  '1000000069',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '70',  '1000000149',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '71',  '1000000150',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '71',  '1000000070',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '72',  '1000000071',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '72',  '1000000151',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '73',  '1000000152',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '73',  '1000000072',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '74',  '1000000073',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '74',  '1000000153',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '75',  '1000000154',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '75',  '1000000074',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '76',  '1000000155',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '76',  '1000000075',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '77',  '1000000076',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '77',  '1000000156',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '78',  '1000000077',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '78',  '1000000157',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '79',  '1000000078',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '79',  '1000000158',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '80',  '1000000079',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '80',  '1000000159',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '1',  '1000000000',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '1',  '1000000160',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '1',  '1000000080',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '2',  '1000000081',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '2',  '1000000161',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '2',  '1000000001',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '3',  '1000000162',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '3',  '1000000082',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '3',  '1000000002',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '4',  '1000000163',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '4',  '1000000003',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '4',  '1000000083',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '5',  '1000000004',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '5',  '1000000164',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '5',  '1000000084',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '6',  '1000000085',  '1',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '6',  '1000000005',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '6',  '1000000165',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '7',  '1000000086',  '1',  '3.0');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '7',  '1000000006',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '7',  '1000000166',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '8',  '1000000007',  '1',  '1.4');

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '8',  '1000000167',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '8',  '1000000087',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '9',  '1000000088',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '9',  '1000000168',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '9',  '1000000008',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '10',  '1000000169',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '10',  '1000000009',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '10',  '1000000089',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '11',  '1000000170',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '11',  '1000000010',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '11',  '1000000090',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '12',  '1000000171',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '12',  '1000000011',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '12',  '1000000091',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '13',  '1000000012',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '13',  '1000000092',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '13',  '1000000172',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '14',  '1000000173',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '14',  '1000000093',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '14',  '1000000013',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '15',  '1000000094',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '15',  '1000000174',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '15',  '1000000014',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '16',  '1000000095',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '16',  '1000000015',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '16',  '1000000175',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '17',  '1000000096',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '17',  '1000000016',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '17',  '1000000176',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000097',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000017',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '18',  '1000000177',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000098',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000018',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '19',  '1000000178',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000179',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000099',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '20',  '1000000019',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000180',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000020',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '21',  '1000000100',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000101',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000181',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '22',  '1000000021',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000182',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000022',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '23',  '1000000102',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000183',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000103',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '24',  '1000000023',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000104',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000024',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '25',  '1000000184',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000025',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000185',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '26',  '1000000105',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000186',  '1',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000106',  '2',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '27',  '1000000026',  '3',  NULL);

INSERT INTO Covers (insurance_id,  order_id, id, health_status_id, extra_price) VALUES (NULL, '28',  '1000000187',  '1',  NULL);




--pricce per country
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Germany', 14.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('France', 10.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Italy', 15.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Spain', 14.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('United Kingdom', 17.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Russia', 5.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('China', 11.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Japan', 8.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('India', 4.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Australia', 17.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Turkey', 8.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Saudi Arabia', 10.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('United Arab Emirates', 14.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Greece', 11.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Netherlands', 16.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Belgium', 11.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Norway', 19.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Sweden', 14.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Denmark', 12.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Czech Republic', 18.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Switzerland', 9.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Austria', 15.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Portugal', 9.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Hungary', 8.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Romania', 19.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Slovakia', 9.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Croatia', 20.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Belarus', 17.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Ukraine', 8.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Kazakhstan', 11.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Uzbekistan', 6.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Tajikistan', 8.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Turkmenistan', 4.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Kyrgyzstan', 10.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Mongolia', 20.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('South Korea', 18.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Iran', 15.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Jordan', 5.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Lebanon', 19.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Cyprus', 19.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Georgia', 4.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Armenia', 17.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Sri Lanka', 4.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Nepal', 4.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Bhutan', 20.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Cambodia', 12.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Myanmar', 13.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Brunei', 4.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Timor-Leste', 20.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Papua New Guinea', 17.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Fiji', 9.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Vanuatu', 7.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Solomon Islands', 7.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Tonga', 20.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Samoa', 8.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Kiribati', 11.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Nauru', 10.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Marshall Islands', 20.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Palau', 12.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Micronesia', 15.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Haiti', 12.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Dominican Republic', 16.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Cuba', 6.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Jamaica', 15.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Trinidad and Tobago', 16.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Barbados', 18.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Saint Lucia', 11.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Saint Vincent', 11.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Grenadines', 13.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Antigua and Barbuda', 6.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Saint Kitts and Nevis', 5.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Bahamas', 6.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Bermuda', 16.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Cayman Islands', 16.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('British Virgin Islands', 16.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Finland', 19.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Ireland', 5.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Iceland', 4.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Poland', 9.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Estonia', 6.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Lithuania', 19.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Latvia', 17.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Bulgaria', 14.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Serbia', 7.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Albania', 20.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Montenegro', 5.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('North Macedonia', 11.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Kosovo', 10.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Malta', 19.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Luxembourg', 12.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Liechtenstein', 5.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Monaco', 6.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('San Marino', 12.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Andorra', 5.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Vatican City', 9.0);
INSERT INTO Price_Per_Country (Country_ID, Price_Per_Day) VALUES ('Slovenia', 9.0);


--days in country
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('1', 'Hungary', 29);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('1', 'Bahamas', 29);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('2', 'Italy', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('2', 'Kosovo', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('2', 'Croatia', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('2', 'United Kingdom', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('2', 'Belgium', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('2', 'Turkmenistan', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('3', 'Marshall Islands', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('3', 'Timor-Leste', 3);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('3', 'South Korea', 3);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('4', 'Andorra', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('4', 'Slovakia', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('4', 'United Kingdom', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('4', 'Latvia', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('5', 'Belarus', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('5', 'Nauru', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('5', 'Finland', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('5', 'Romania', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('5', 'Albania', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('6', 'Saudi Arabia', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('6', 'Vatican City', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('6', 'Norway', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('6', 'Sri Lanka', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('6', 'Micronesia', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('7', 'Barbados', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('7', 'Iceland', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('7', 'Russia', 3);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('8', 'Russia', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('8', 'United Arab Emirates', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('8', 'British Virgin Islands', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('8', 'Nauru', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('8', 'Italy', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('9', 'Belarus', 28);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('9', 'Cyprus', 27);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('10', 'Austria', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('10', 'Marshall Islands', 11);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('10', 'France', 11);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('11', 'Finland', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('11', 'British Virgin Islands', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('11', 'Vanuatu', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('11', 'Netherlands', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('12', 'Saint Vincent', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('12', 'Ukraine', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('12', 'Liechtenstein', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('12', 'United Arab Emirates', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('12', 'Austria', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('12', 'Iran', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('13', 'Kosovo', 22);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('14', 'Fiji', 3);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('14', 'Saint Vincent', 3);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('14', 'Dominican Republic', 3);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('14', 'British Virgin Islands', 3);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('14', 'South Korea', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('15', 'Barbados', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('15', 'Belgium', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('15', 'United Kingdom', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('15', 'India', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('15', 'Malta', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('16', 'Vatican City', 19);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('16', 'Ireland', 19);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('17', 'Estonia', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('17', 'Lithuania', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('17', 'Sweden', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('17', 'Serbia', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('17', 'Ireland', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('17', 'Luxembourg', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('18', 'Portugal', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('18', 'Albania', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('18', 'Trinidad and Tobago', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('18', 'Sri Lanka', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('18', 'Jordan', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('19', 'Netherlands', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('19', 'Brunei', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('19', 'Kazakhstan', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('19', 'Saint Vincent', 11);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('19', 'Tonga', 11);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('20', 'Brunei', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('20', 'Cayman Islands', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('20', 'Norway', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('20', 'Uzbekistan', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('21', 'Poland', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('21', 'Grenadines', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('22', 'Iceland', 26);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('22', 'San Marino', 26);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('23', 'Cuba', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('23', 'Barbados', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('23', 'India', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('23', 'Trinidad and Tobago', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('23', 'Germany', 0);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('24', 'Cambodia', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('24', 'Turkey', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('24', 'United Kingdom', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('25', 'Trinidad and Tobago', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('25', 'Hungary', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('25', 'Monaco', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('25', 'Montenegro', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('25', 'Bhutan', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('26', 'Jordan', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('26', 'Fiji', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('26', 'Austria', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('26', 'United Arab Emirates', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('26', 'Cuba', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('26', 'Saint Lucia', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('27', 'France', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('27', 'Slovenia', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('27', 'Norway', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('27', 'Lebanon', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('27', 'Armenia', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('28', 'Norway', 15);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('28', 'Georgia', 15);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('29', 'Bermuda', 13);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('29', 'India', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('29', 'Switzerland', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('30', 'Turkmenistan', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('30', 'Estonia', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('30', 'Sri Lanka', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('30', 'Liechtenstein', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('30', 'Cyprus', 0);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('30', 'Latvia', 0);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('31', 'Belarus', 18);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('31', 'Iran', 18);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('32', 'Portugal', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('32', 'Lebanon', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('32', 'Mongolia', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('33', 'United Kingdom', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('33', 'Belgium', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('33', 'Saint Lucia', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('33', 'Greece', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('33', 'Montenegro', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('33', 'Armenia', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('34', 'Nepal', 52);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('35', 'Kazakhstan', 20);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('36', 'Cuba', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('36', 'Hungary', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('36', 'Nepal', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('36', 'Timor-Leste', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('37', 'Mongolia', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('37', 'Netherlands', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('37', 'Japan', 0);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('37', 'Vanuatu', 0);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('38', 'Grenadines', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('38', 'Papua New Guinea', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('38', 'Romania', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('38', 'Iceland', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('39', 'Czech Republic', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('39', 'Poland', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('39', 'Palau', 3);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('39', 'Japan', 3);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('39', 'Finland', 3);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('40', 'Kyrgyzstan', 18);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('40', 'India', 18);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('40', 'Lithuania', 17);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('41', 'Monaco', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('42', 'United Arab Emirates', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('42', 'Antigua and Barbuda', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('42', 'Brunei', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('43', 'Australia', 3);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('43', 'Poland', 3);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('43', 'Saint Lucia', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('43', 'Liechtenstein', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('43', 'Sri Lanka', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('43', 'Luxembourg', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('44', 'Liechtenstein', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('44', 'Ukraine', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('44', 'Barbados', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('44', 'Luxembourg', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('44', 'United Kingdom', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('44', 'France', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('45', 'South Korea', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('45', 'Monaco', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('45', 'Denmark', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('45', 'Poland', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('46', 'Croatia', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('46', 'Vatican City', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('46', 'Tajikistan', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('46', 'Georgia', 0);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('47', 'China', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('47', 'Fiji', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('47', 'Norway', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('47', 'Grenadines', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('47', 'Liechtenstein', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('47', 'Finland', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('48', 'Timor-Leste', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('48', 'Jamaica', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('48', 'Haiti', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('48', 'Austria', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('49', 'Sri Lanka', 15);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('49', 'Nauru', 15);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('50', 'Georgia', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('51', 'Netherlands', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('51', 'Cuba', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('51', 'Albania', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('51', 'Fiji', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('51', 'Jamaica', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('51', 'Latvia', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('52', 'Monaco', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('52', 'Liechtenstein', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('53', 'Hungary', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('53', 'Portugal', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('53', 'Georgia', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('53', 'Marshall Islands', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('53', 'Armenia', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('54', 'Lithuania', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('54', 'South Korea', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('54', 'Norway', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('54', 'Bhutan', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('54', 'Grenadines', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('55', 'British Virgin Islands', 5);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('56', 'Spain', 15);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('56', 'Mongolia', 15);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('56', 'Bermuda', 15);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('56', 'United Kingdom', 15);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('57', 'Portugal', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('57', 'Luxembourg', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('57', 'Nauru', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('57', 'North Macedonia', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('58', 'Armenia', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('58', 'Albania', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('58', 'Japan', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('59', 'Japan', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('59', 'Croatia', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('59', 'Slovenia', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('59', 'Czech Republic', 4);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('59', 'Montenegro', 3);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('60', 'Kyrgyzstan', 14);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('60', 'Turkey', 13);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('61', 'San Marino', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('61', 'Germany', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('61', 'Ukraine', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('61', 'Monaco', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('61', 'Greece', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('62', 'Japan', 25);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('62', 'Norway', 25);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('63', 'Tajikistan', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('63', 'Nauru', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('63', 'Jordan', 2);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('63', 'Luxembourg', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('63', 'Kazakhstan', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('63', 'North Macedonia', 1);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('64', 'Brunei', 25);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('64', 'Barbados', 25);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('65', 'Mongolia', 11);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('65', 'India', 11);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('65', 'Hungary', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('65', 'Austria', 10);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('66', 'Vanuatu', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('66', 'Hungary', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('66', 'Jamaica', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('66', 'Kiribati', 11);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('67', 'Finland', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('67', 'Nepal', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('67', 'Palau', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('67', 'United Arab Emirates', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('67', 'Andorra', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('68', 'Tonga', 14);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('68', 'Uzbekistan', 13);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('69', 'Cuba', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('69', 'Ireland', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('69', 'Latvia', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('70', 'Lithuania', 15);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('70', 'Russia', 15);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('70', 'Vanuatu', 14);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('70', 'Belarus', 14);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('71', 'Ireland', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('71', 'Liechtenstein', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('71', 'India', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('72', 'Turkmenistan', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('72', 'Marshall Islands', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('72', 'Myanmar', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('72', 'Denmark', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('73', 'Bhutan', 28);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('73', 'Estonia', 28);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('74', 'Kazakhstan', 59);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('75', 'Latvia', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('75', 'Kyrgyzstan', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('75', 'Liechtenstein', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('75', 'Haiti', 12);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('75', 'Armenia', 11);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('76', 'Liechtenstein', 25);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('77', 'India', 7);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('77', 'Croatia', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('77', 'Saudi Arabia', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('77', 'Latvia', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('78', 'Tajikistan', 6);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('79', 'United Kingdom', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('79', 'Dominican Republic', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('79', 'Fiji', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('79', 'Liechtenstein', 9);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('79', 'Spain', 8);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('80', 'Germany', 11);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('80', 'Turkey', 11);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('80', 'Haiti', 11);
INSERT INTO Days_in_Country (Order_ID, Country_ID, Total_Days) VALUES ('80', 'Cyprus', 10);

